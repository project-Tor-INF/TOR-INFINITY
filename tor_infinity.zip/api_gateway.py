import http.server
import socketserver
import json
import socket
import os

PORT = 8000

# HTML Frontend for the "Official" Portal
HTML_PAGE = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TOR-INFINITY // Secure Mesh Gateway</title>
    <style>
        :root {
            --bg-color: #0a0a0c;
            --panel-bg: #121318;
            --border-color: #1e222d;
            --accent: #00ff66;
            --accent-dim: rgba(0, 255, 102, 0.1);
            --text-main: #e2e8f0;
            --text-muted: #94a3b8;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Courier New', Courier, monospace; }
        body { background-color: var(--bg-color); color: var(--text-main); display: flex; justify-content: center; align-items: center; min-height: 100vh; padding: 20px; }
        .container { width: 100%; max-width: 650px; background: var(--panel-bg); border: 1px solid var(--border-color); border-radius: 8px; padding: 30px; box-shadow: 0 10px 30px rgba(0,0,0,0.8); }
        .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; border-bottom: 1px solid var(--border-color); padding-bottom: 15px; }
        .logo { font-size: 1.2rem; font-weight: bold; color: var(--accent); letter-spacing: 2px; }
        .status { font-size: 0.8rem; background: var(--accent-dim); color: var(--accent); padding: 4px 10px; border-radius: 4px; border: 1px solid var(--accent); }
        .form-group { margin-bottom: 20px; }
        label { display: block; font-size: 0.85rem; color: var(--text-muted); margin-bottom: 8px; text-transform: uppercase; letter-spacing: 1px; }
        select, textarea { width: 100%; background: #08090c; border: 1px solid var(--border-color); color: var(--text-main); padding: 12px; border-radius: 4px; font-size: 0.95rem; outline: none; transition: border-color 0.2s; }
        select:focus, textarea:focus { border-color: var(--accent); }
        textarea { resize: vertical; min-height: 120px; }
        button { background: var(--accent); color: #000; border: none; width: 100%; padding: 14px; font-weight: bold; font-size: 1rem; border-radius: 4px; cursor: pointer; text-transform: uppercase; letter-spacing: 1px; transition: opacity 0.2s; }
        button:hover { opacity: 0.9; }
        .terminal-output { margin-top: 25px; background: #050507; border: 1px solid var(--border-color); padding: 15px; border-radius: 4px; font-size: 0.85rem; max-height: 180px; overflow-y: auto; color: var(--accent); display: none; }
        .terminal-output.active { display: block; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="logo">TOR-INFINITY // MESH</div>
            <div class="status">● CIRCUIT ACTIVE</div>
        </div>
        
        <form id="postForm">
            <div class="form-group">
                <label for="board">Target Board</label>
                <select id="board" name="board">
                    <option value="general">/general/ - Core Protocol</option>
                    <option value="tech">/tech/ - Systems & Architecture</option>
                    <option value="crypto">/crypto/ - Lattice & LWE Encryption</option>
                </select>
            </div>
            
            <div class="form-group">
                <label for="content">Anonymous Payload</label>
                <textarea id="content" name="content" placeholder="Type your anonymous transmission..." required></textarea>
            </div>
            
            <button type="submit" id="submitBtn">Broadcast Anonymously</button>
        </form>

        <div id="output" class="terminal-output"></div>
    </div>

    <script>
        document.getElementById('postForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            const btn = document.getElementById('submitBtn');
            const output = document.getElementById('output');
            
            btn.disabled = true;
            btn.innerText = 'Routing through 3-hop mesh...';
            
            const payload = {
                board: document.getElementById('board').value,
                content: document.getElementById('content').value
            };

            try {
                const response = await fetch('/api/v1/post/anonymous', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });
                const result = await response.json();
                
                output.classList.add('active');
                output.innerHTML = `> Status: ${result.status}<br>> Message: ${result.message}<br>> Ack: ${result.circuit_acknowledgment}`;
            } catch (err) {
                output.classList.add('active');
                output.innerHTML = `> ERROR: Transmission failed to traverse mesh circuit.`;
            } finally {
                btn.disabled = false;
                btn.innerText = 'Broadcast Anonymously';
            }
        });
    </script>
</body>
</html>
"""

def simple_xor_encrypt(data: bytes, key: bytes) -> bytes:
    return bytes(b ^ key[i % len(key)] for i, b in enumerate(data))

def build_onion_packet(raw_payload: bytes) -> bytes:
    exit_key = os.urandom(16)
    middle_key = os.urandom(16)
    entry_key = os.urandom(16)

    layer3 = exit_key + simple_xor_encrypt(raw_payload, exit_key)
    layer2 = middle_key + simple_xor_encrypt(layer3, middle_key)
    onion_packet = entry_key + simple_xor_encrypt(layer2, entry_key)
    return onion_packet

class TorInfinityHandler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/" or self.path == "/index.html":
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(HTML_PAGE.encode('utf-8'))
        else:
            self.send_response(404)
            self.end_headers()

    def do_POST(self):
        if self.path == "/api/v1/post/anonymous":
            content_length = int(self.headers.get('Content-Length', 0))
            body = self.rfile.read(content_length)
            
            try:
                data = json.loads(body)
                post_content = data.get("content", "Anonymous transmission")
                board = data.get("board", "general")

                payload_str = f"BOARD:{board}|CONTENT:{post_content}"
                raw_payload = payload_str.encode('utf-8')

                # Wrap in 3-layer onion encryption
                onion_packet = build_onion_packet(raw_payload)

                # Dispatch into Entry Node (Port 8081)
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                    s.connect(("127.0.0.1", 8081))
                    s.sendall(onion_packet)
                    response = s.recv(2048)

                response_data = {
                    "status": "success",
                    "message": "Anonymous payload routed successfully through 3-hop mesh.",
                    "circuit_acknowledgment": response.decode('utf-8', errors='ignore')
                }

                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps(response_data).encode('utf-8'))

            except Exception as e:
                self.send_response(500)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps({"error": str(e)}).encode('utf-8'))
        else:
            self.send_response(404)
            self.end_headers()

    def log_message(self, format, *args):
        print(f"[PORTAL] {self.client_address[0]} - {format%args}")

if __name__ == "__main__":
    print(f"[TOR-INFINITY PORTAL] Official web interface live at http://127.0.0.1:{PORT}")
    with socketserver.TCPServer(("127.0.0.1", PORT), TorInfinityHandler) as httpd:
        httpd.serve_forever()
