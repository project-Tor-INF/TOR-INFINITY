import socket
import binascii

def send_hex_packet(host, port, hex_payload):
    print(f"[*] Connecting to {host}:{port}...")
    
    # Convert hex string to raw bytes
    try:
        payload_bytes = binascii.unhexlify(hex_payload.replace(" ", ""))
    except Exception as e:
        print(f"[-] Hex conversion error: {e}")
        return

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((host, port))
        print(f"[+] Connected! Sending hex payload: {hex_payload}")
        
        # Send raw bytes through the entry node
        s.sendall(payload_bytes)
        
        # Read the echo response from the mesh circuit
        response = s.recv(2048)
        hex_response = binascii.hexlify(response).decode('utf-8')
        
        print(f"[+] Received raw bytes back ({len(response)} bytes):")
        print(f"    HEX: {hex_response}")

if __name__ == "__main__":
    # Example test packet: Hex representation of a secure handshake header + payload
    # "TOR-INFINITY" in hex is 544f522d494e46494e495459
    test_hex = "544f522d494e46494e4954590102030405060708"
    
    # Target the Entry Node on port 8081
    send_hex_packet("127.0.0.1", 8081, test_hex)
