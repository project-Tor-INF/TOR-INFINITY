use tokio::net::TcpListener;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::time::{sleep, Duration};
use rand::Rng;

async fn run_relay_node(port: u16, role: &'static str) -> Result<(), Box<dyn std::error::Error>> {
    let listener = TcpListener::bind(format!("127.0.0.1:{}", port)).await?;
    println!("[MESH RELAY - {}] Active on port {}", role, port);

    while let Ok((mut socket, addr)) = listener.accept().await {
        println!("[{}] Inbound connection from {}", role, addr);
        tokio::spawn(async move {
            let mut buf = vec![0u8; 2048];
            loop {
                match socket.read(&mut buf).await {
                    Ok(0) => break,
                    Ok(n) => {
                        // Simulate covert relay jitter
                        let delay: u64 = rand::thread_rng().gen_range(5..15);
                        sleep(Duration::from_millis(delay)).await;

                        if socket.write_all(&buf[..n]).await.is_err() {
                            break;
                        }
                    }
                    Err(_) => break,
                }
            }
        });
    }
    Ok(())
}

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    println!("[TOR-INFINITY MESH] Initializing 3-Hop Covert Circuit...");

    // Spawn Entry, Middle, and Exit relays concurrently across ports
    tokio::try_join!(
        run_relay_node(8081, "ENTRY NODE"),
        run_relay_node(8082, "MIDDLE RELAY"),
        run_relay_node(8083, "EXIT NODE")
    )?;

    Ok(())
}
