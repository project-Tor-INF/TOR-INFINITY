import socket
import binascii
import os

def simple_xor_encrypt(data: bytes, key: bytes) -> bytes:
    """Simulates symmetric layer encryption (e.g., ChaCha20/AES-GCM per hop)"""
    return bytes(b ^ key[i % len(key)] for i, b in enumerate(data))

def build_onion_packet(raw_payload: bytes) -> bytes:
    """
    Wraps the payload in 3 concentric encryption layers:
    Layer 3 (Exit Node target) -> Layer 2 (Middle Relay target) -> Layer 1 (Entry Node target)
    """
    print("[*] Generating ephemeral keys for 3-hop circuit...")
    exit_key = os.urandom(16)
    middle_key = os.urandom(16)
    entry_key = os.urandom(16)

    # Layer 3: Encrypt original payload for the Exit node
    # Format: [Exit Key (16B)] + [Encrypted Payload]
    layer3_payload = exit_key + simple_xor_encrypt(raw_payload, exit_key)

    # Layer 2: Encrypt Layer 3 for the Middle relay
    layer2_payload = middle_key + simple_xor_encrypt(layer3_payload, middle_key)

    # Layer 1: Encrypt Layer 2 for the Entry relay (Port 8081)
    onion_packet = entry_key + simple_xor_encrypt(layer2_payload, entry_key)

    print("[+] Onion packet constructed successfully:")
    print(f"    Total wrapped size: {len(onion_packet)} bytes")
    return onion_packet

def send_onion_packet(host, port, hex_payload):
    try:
        raw_payload = binascii.unhexlify(hex_payload.replace(" ", ""))
    except Exception as e:
        print(f"[-] Hex error: {e}")
        return

    # Wrap in onion encryption
    onion_packet = build_onion_packet(raw_payload)

    print(f"[*] Dispatching onion packet to Entry Node {host}:{port}...")
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((host, port))
        s.sendall(onion_packet)
        
        response = s.recv(2048)
        print(f"[+] Circuit response received ({len(response)} bytes):")
        print(f"    HEX: {binascii.hexlify(response).decode('utf-8')}")

if __name__ == "__main__":
    # Test secure payload in hex ("TOR-INFINITY COMMAND PAYLOAD")
    test_hex = "544f522d494e46494e49545920434f4d4d414e44"
    send_onion_packet("127.0.0.1", 8081, test_hex)
